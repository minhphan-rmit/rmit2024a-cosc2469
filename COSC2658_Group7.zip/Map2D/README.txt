Contribution Score:
- Phan Nhat Minh (s3978598): 5
- Tran Ha Phuong (S3979638): 5
- Tran Manh Cuong (S3974735): 5
- Truong Quang Bao Loc (s3965528): 5

Video Link: https://youtu.be/ghDEBK4qFTc